/*
Project: Car Dealership Team Project
Purpose Details: A text-based car dealership system
Course: IST 242
Author: Elyse Swider
Date Developed: 6/13/2020
Last Date Changed: 6/21/2020
Revision: 2
 */
package com.company;

public class User {

        private Integer idNumber;

        private String FName;

        private String LName;

        private Date Birthday;

        private String Address;

        private Integer PhoneNumber;

        private Integer SSN;

        private Boolean Active;



    }

}
